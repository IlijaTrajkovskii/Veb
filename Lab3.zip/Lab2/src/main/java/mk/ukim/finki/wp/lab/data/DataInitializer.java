package mk.ukim.finki.wp.lab.data;


import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import mk.ukim.finki.wp.lab.model.Album;
import mk.ukim.finki.wp.lab.model.Artist;
import mk.ukim.finki.wp.lab.repository.AlbumRepository;
import mk.ukim.finki.wp.lab.repository.ArtistRepository;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class DataInitializer {

    private final AlbumRepository albumRepository;
    private final ArtistRepository artistRepository;


    @PostConstruct
    public void initializeAlbumData()
    {

        for(int i=1;i<4;i++)
        {
            Album album = new Album("Name " + i,"Genre " + i, "ReleaseYear " +i);
            albumRepository.save(album);

        }

    }


    @PostConstruct
    public void initializeArtistData()
    {

        for(int i=1;i<4;i++)
        {
            Artist artist = new Artist("Name "+i, "LastName " +i, "bio "+ i);
            artistRepository.save(artist);


        }

    }


}
