package mk.ukim.finki.wp.lab.model;


import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.*;

@Data
@Entity
@Table
@AllArgsConstructor
@NoArgsConstructor
public class Artist {

    @Id
    @GeneratedValue
    private Long id;
    private String FirstName;
    private String LastName;
    private String bio;

    public Artist(String firstName, String lastName, String bio) {
        FirstName = firstName;
        LastName = lastName;
        this.bio = bio;
    }
}
