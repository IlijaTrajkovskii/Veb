package mk.ukim.finki.wp.lab.web.controller;

import lombok.AllArgsConstructor;
import mk.ukim.finki.wp.lab.model.Artist;
import mk.ukim.finki.wp.lab.model.Song;
import mk.ukim.finki.wp.lab.service.ArtistService;
import mk.ukim.finki.wp.lab.service.SongService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@AllArgsConstructor
public class SongDetailsController {

    private final ArtistService artistService;
    private final SongService songService;

    @PostMapping("/songDetailsPage")
    public String songDetailsPage(@RequestParam(name = "PesnaID") Long Id,
                                  @RequestParam(name = "artistRed") Long artistId,
                                  Model model) throws Exception
    {
        Artist artistot = artistService.ArtistfindById(artistId).orElse(null);
        Song song = songService.findSongById(Id);

        songService.addArtistToSong(artistot,song);

        model.addAttribute("Song", song);

        return "songDetails";

    }
}
