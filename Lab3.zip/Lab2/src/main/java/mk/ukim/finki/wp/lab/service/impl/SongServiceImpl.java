package mk.ukim.finki.wp.lab.service.impl;

import lombok.AllArgsConstructor;
import mk.ukim.finki.wp.lab.model.Album;
import mk.ukim.finki.wp.lab.model.Artist;
import mk.ukim.finki.wp.lab.model.Song;
import mk.ukim.finki.wp.lab.repository.AlbumRepository;
import mk.ukim.finki.wp.lab.repository.ArtistRepository;
import mk.ukim.finki.wp.lab.repository.SongRepository;
import mk.ukim.finki.wp.lab.service.SongService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@AllArgsConstructor
public class SongServiceImpl implements SongService {

    private final ArtistRepository artistRepository;
    private final SongRepository songRepository;
    private final AlbumRepository albumRepository;

    @Override
    public List<Song> findSongsByAlbumId(Long AlbumId)
    {
        return songRepository.findAllByAlbumId(AlbumId);
    }

    @Override
    public Song findSongById(Long songId) throws Exception {

        return songRepository.findById(songId).orElseThrow(Exception::new);
    }

    @Override
    public Song saveSong(String title, String trackId, String genre, int releaseYear, Long AlbumId) throws Exception {

        //proveri dali treba dae void
        //vrakja optional
        Album album = albumRepository.findById(AlbumId).orElseThrow(Exception::new);
        Song song = new Song(title, trackId, genre, releaseYear, album);

        songRepository.save(song);
        return song;
    }




    @Override
    public Song editSong(Long songId, String title, String trackId, String genre, int releaseYear, Long AlbumId) throws Exception {

       Song song = songRepository.findById(songId).orElseThrow(Exception::new);
       Album album = albumRepository.findById(AlbumId).orElseThrow(Exception::new);

       song.setTitle(title);
       song.setTrackId(trackId);
       song.setGenre(genre);
       song.setReleaseYear(releaseYear);
       song.setAlbum(album);

       //mora pak nazad da se zacuva promenata vo baza

       return songRepository.save(song);

    }




    @Override
    public void deleteSong(Long songId)
    {

        songRepository.deleteById(songId);
    }





    @Override
    public List<Song> listSongs() {

        return songRepository.findAll();
    }

    @Override
    public Artist addArtistToSong(Artist artist, Song song) {

        song.getPerformers().add(artist);
        //dodavame za da zacuvame  vo baza
        songRepository.save(song);

        return artist;
    }

    // ova e spored TrackID , mozno e da treba i SO LONG ID da mozeme da vratime konkretna pesna
    @Override
    public Song findByTrackId(String trackId) {

        return songRepository.findByTrackId(trackId);
    }

}
