package mk.ukim.finki.wp.lab.service;

import mk.ukim.finki.wp.lab.model.Artist;
import mk.ukim.finki.wp.lab.model.Song;

import java.util.List;

public interface SongService {

    List<Song> listSongs();

    Song findByTrackId(String trackId);
    Song findSongById(Long songId) throws Exception;

    // ZA LAB 2
    Song saveSong(String title,String trackId, String genre,int releaseYear , Long AlbumId) throws Exception;
    Song editSong(Long songId,String title,String trackId, String genre,int releaseYear , Long AlbumId) throws Exception;
    void deleteSong(Long songId);


    List<Song> findSongsByAlbumId(Long AlbumId);

    Artist addArtistToSong(Artist artist, Song song);

}
