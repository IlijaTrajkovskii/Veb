package mk.ukim.finki.wp.lab.repository;


import jakarta.annotation.PostConstruct;
import mk.ukim.finki.wp.lab.model.Album;
import mk.ukim.finki.wp.lab.model.Artist;
import mk.ukim.finki.wp.lab.model.Song;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Repository
public class SongRepository {

    List<Song> SongList = new ArrayList<>();

    private final AlbumRepository albumRepository;

    public SongRepository(AlbumRepository albumRepository) {
        this.albumRepository = albumRepository;
    }

    @PostConstruct
    public void initializeData ()
    {
        for(int i=0;i<5;i++)
        {
            // proveri za poslednoto da ne treba kastiranje vo long deka samo kec 1 vnesuvas
            Song song = new Song("TrackID " + i,"Title " + i, "Genre " + i, i, (long) (Math.random()*1000),albumRepository.FindByAlbumByID((long) i) );
            SongList.add(song);

        }
    }

    public Song saveSong(String title, String trackId, String genre, int releaseYear, Long AlbumId)
    {
        // prvind da go najdeme albumot za pesnata

        Album album = albumRepository.FindByAlbumByID(AlbumId);

        Song song = new Song(trackId,title,genre,releaseYear, UUID.randomUUID().getMostSignificantBits(),album);

        SongList.add(song);

        return song;
    }

    public Song editSong(Long songId, String title, String trackId, String genre, int releaseYear, Long AlbumId)
    {

        Song song = findSongById(songId);
        Album album = albumRepository.FindByAlbumByID(AlbumId);

        song.setTitle(title);
        song.setTrackId(trackId);
        song.setGenre(genre);
        song.setReleaseYear(releaseYear);
        song.setAlbum(album);

        return song;

    }

    public void deleteSong(Long songId)
    {
        SongList.removeIf(song -> song.getId().equals(songId));
    }

    public Song findSongById(Long songId)
    {
        return SongList.stream().filter(song -> song.getId().equals(songId)).findFirst().orElse(null);
    }


//1
    public List<Song> findAll()
    {
        return SongList;
    }

//2
    public Song findByTrackId(String trackId)
    {
        //bidejki findFirst vrakja Optional, morame orElse null ako song ne e najdena

        return SongList.stream().filter(song -> song.getTrackId().equals(trackId)).findFirst().orElse(null);

    }
//3
    public Artist addArtistToSong(Artist artist, Song song)
    {
        song.getPerformers().add(artist);
        return artist;

    }



}
