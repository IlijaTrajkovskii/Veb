package mk.ukim.finki.wp.lab.web.controller;

import lombok.AllArgsConstructor;
import mk.ukim.finki.wp.lab.service.ArtistService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@AllArgsConstructor
public class ArtistController {

    private final ArtistService artistService;

    @PostMapping("/artists")
    public String getSongsPage(@RequestParam(required = false) String error,
            @RequestParam(name = "PesnaRed") String trackId, Model model)
    {
        model.addAttribute("artists",artistService.listArtists());
        model.addAttribute("trackID",trackId );


        return "/artistsList";
    }

}
