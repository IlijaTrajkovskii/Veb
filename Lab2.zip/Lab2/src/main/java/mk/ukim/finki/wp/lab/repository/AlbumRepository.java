package mk.ukim.finki.wp.lab.repository;


import jakarta.annotation.PostConstruct;
import lombok.Getter;
import lombok.Setter;
import mk.ukim.finki.wp.lab.model.Album;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
@Getter
@Setter
public class AlbumRepository {

    List<Album> albums = new ArrayList<Album>();

    @PostConstruct
    public void init()
    {
        for(int i = 0 ; i < 5 ; i++)
        {
            // proveri dali mozes vaka so kastiranjevo
            Album album= new Album ((long) i, "Name" + i, "Genre : " +i, "Release year :"+ i );
            albums.add(album);
        }

    }
    public List<Album> findAll()
    {
        return albums;
    }

    public Album FindByAlbumByID (Long id)
    {
       return albums.stream().filter(album -> album.getId().equals(id)).findFirst().orElse(null);
    }

}
