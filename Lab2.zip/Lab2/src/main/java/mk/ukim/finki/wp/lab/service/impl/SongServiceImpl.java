package mk.ukim.finki.wp.lab.service.impl;

import mk.ukim.finki.wp.lab.model.Artist;
import mk.ukim.finki.wp.lab.model.Song;
import mk.ukim.finki.wp.lab.repository.ArtistRepository;
import mk.ukim.finki.wp.lab.repository.SongRepository;
import mk.ukim.finki.wp.lab.service.SongService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SongServiceImpl implements SongService {

    private final ArtistRepository artistRepository;
    private final SongRepository songRepository;

    public SongServiceImpl(ArtistRepository artistRepository, SongRepository songRepository) {
        this.artistRepository = artistRepository;
        this.songRepository = songRepository;
    }


    @Override
    public Song findSongById(Long songId) {
        return songRepository.findSongById(songId);
    }

    @Override
    public Song saveSong(String title, String trackId, String genre, int releaseYear, Long AlbumId)
    {
        return songRepository.saveSong(title,trackId,genre,releaseYear,AlbumId);
    }




    @Override
    public Song editSong(Long songId, String title, String trackId, String genre, int releaseYear, Long AlbumId)
    {
       return songRepository.editSong(songId,title,trackId,genre,releaseYear,AlbumId);
    }




    @Override
    public void deleteSong(Long songId)
    {

        songRepository.deleteSong(songId);
    }













    @Override
    public List<Song> listSongs() {
        return songRepository.findAll();
    }

    @Override
    public Artist addArtistToSong(Artist artist, Song song) {

        return songRepository.addArtistToSong(artist,song);
    }

    // ova e spored TrackID , mozno e da treba i SO LONG ID da mozeme da vratime konkretna pesna
    @Override
    public Song findByTrackId(String trackId) {

        return songRepository.findByTrackId(trackId);
    }

}
