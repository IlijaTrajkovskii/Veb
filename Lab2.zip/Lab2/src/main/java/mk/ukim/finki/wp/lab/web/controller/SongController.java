package mk.ukim.finki.wp.lab.web.controller;


import mk.ukim.finki.wp.lab.service.AlbumService;
import org.springframework.ui.Model;
import lombok.AllArgsConstructor;
import mk.ukim.finki.wp.lab.service.SongService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@AllArgsConstructor
public class SongController {


    // imame allArgsConstructor pa ne ni treba poseben constructor based dependency injection
    private final SongService songService;
    private final AlbumService albumService;



    @GetMapping("/songs")
    public String getSongsPage(@RequestParam(required = false) String error,Model model)
    {
        model.addAttribute("songs", songService.listSongs());

        //ako erroror postoi t.e e razlicno od null
        if (error != null)
        {
            model.addAttribute("error", error);
        }

        return "listSongs";


    }

    @GetMapping("/songs/add-form")
    public String getAddSongPage(@RequestParam(required = false) String error,Model model)
    {

        model.addAttribute("albums",albumService.findAll());
        return "add-song";
    }


    @GetMapping("/songs/edit-form/{id}")
    public String getEditSongForm(@PathVariable(name="id") Long songId,
                                  @RequestParam(required = false) String error, Model model)
    {

        // ova albums e za select tagot da gi listame site albumi, im go listame id-to
        model.addAttribute("albums",albumService.findAll());

        //ova e informacii za da znaeme koja konkretna song ja edituvame, so cel da ni ostanat momentalnite podatoci za pesnata
        model.addAttribute("song",songService.findSongById(songId));

        //proveruvame dali pesnata postoi preku nejzinoto ID
      var song = songService.findSongById(songId);

      if(song == null)
      {
          return "redirect:/songs?error=Song+ID+not+found";
      }

        return "add-song";
    }




    @PostMapping("/songs/add")
    public String saveSong(@RequestParam(name = "title") String title,
                           @RequestParam(name = "trackId") String trackId,
                           @RequestParam(name = "genre") String genre,
                           @RequestParam(name = "releaseYear") int releaseYear,
                           @RequestParam(name = "albumId") Long albumId) {

        //dodavame pesni

        songService.saveSong(title, trackId, genre, releaseYear, albumId);

        return "redirect:/songs";

    }

    @PostMapping("/songs/edit/{songId}")
    public String editSong(@PathVariable(name = "songId") Long songId,
                           @RequestParam(name = "title") String title,
                           @RequestParam(name = "trackId") String trackId,
                           @RequestParam(name = "genre") String genre,
                           @RequestParam(name = "releaseYear") int releaseYear,
                           @RequestParam(name = "albumId") Long albumId) {


        //editirame konkretna pesna

        songService.editSong(songId, title, trackId, genre, releaseYear, albumId);
        return "redirect:/songs";
    }

    @GetMapping("/songs/delete/{songId}")
    public String deleteSong(@PathVariable(name = "songId") Long songId) {

        //briseme konkretna pesna

        songService.deleteSong(songId);

        return "redirect:/songs";
    }







}
