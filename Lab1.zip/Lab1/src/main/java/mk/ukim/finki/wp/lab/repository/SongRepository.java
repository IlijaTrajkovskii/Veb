package mk.ukim.finki.wp.lab.repository;


import jakarta.annotation.PostConstruct;
import mk.ukim.finki.wp.lab.model.Artist;
import mk.ukim.finki.wp.lab.model.Song;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class SongRepository {

    List<Song> SongList = new ArrayList<>();




    @PostConstruct
    public void initializeData ()
    {
        for(int i=0;i<5;i++)
        {
            // proveri za poslednoto
            Song song = new Song("TrackID " + i,"Title " + i, "Genre " + i, i);
            SongList.add(song);

        }
    }
//1
    public List<Song> findAll()
    {
        return SongList;
    }

//2
    public Song findByTrackId(String trackId)
    {
        //bidejki findFirst vrakja Optional, morame orElse null ako song ne e najdena

        return SongList.stream().filter(song -> song.getTrackId().equals(trackId)).findFirst().orElse(null);

    }
//3
    public Artist addArtistToSong(Artist artist, Song song)
    {
        song.getPerformers().add(artist);
        return artist;

    }



}
