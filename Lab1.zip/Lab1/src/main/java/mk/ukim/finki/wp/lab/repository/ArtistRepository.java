package mk.ukim.finki.wp.lab.repository;

import jakarta.annotation.PostConstruct;
import mk.ukim.finki.wp.lab.model.Artist;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Repository
public class ArtistRepository {

    List<Artist> artistList = new ArrayList<>();


    @PostConstruct
    public void initializeData ()
    {
        for(int i=0;i<5;i++)
        {
            Artist artist = new Artist(i, "FirstName " +i ,"LastName " + i, "bio " +i );
            artistList.add(artist);
        }
    }

    public List<Artist> findAll()
    {
        return artistList;
    }

    public Optional<Artist> findById(long id)
    {
       return artistList.stream().filter(artist -> artist.getId() == id).findFirst();
    }


}
